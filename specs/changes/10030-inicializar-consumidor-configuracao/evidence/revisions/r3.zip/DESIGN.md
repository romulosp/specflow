# Design candidato — inicialização e configuração

Revisão r3. Depende dos contratos de evidência e gates da Change 10029 r5. Interfaces lógicas propostas, sem CLI/binário implementado:

1. `initialize_consumer(root, catalog)`: cria somente esqueleto autorizado, template privado configuracao.properties com valores DEFINIR e regra de ignore. Não inicia integrações.
2. `resolve_resource(id, properties)`: valida campos/estado e retorna inativo por configuração, configuração inválida ou disponível para uma ação autorizada. Não testa rede nem executável.
3. `generate_application(root, id, templates, approved_scope)`: verifica gate de SPEC, confinamento e conflitos; prepara apps e escreve somente destinos autorizados sem conflito.

## Propriedade dos arquivos

| Artefato | Dono e atualização |
| --- | --- |
| configuracao.properties | Consumidor; criado com DEFINIR e passa a ser autoral. Nunca substituir valores preenchidos por upgrade/reinit |
| configuracao.example.properties | Template sem segredos reais; catálogo versionado do framework |
| Catálogo de recursos | Framework/extensão; ID, campos, tipos, obrigatoriedade/autenticação suportada e capacidades; não contém credenciais |
| Metadados/lock internos | Ferramenta; versões/digests/ownership, sem URLs privadas ou credenciais duplicadas |
| apps/ | Código e dados autorais do consumidor; geração não pode apagá-los para obter idempotência |

Não há dependência de um checkout anterior. O exemplo desta Change é modelo inicial, não afirma que todas as Skills copiadas já possuem adaptador executável. Toda capacidade adicional deve declarar campos, modo de autenticação e política de execução antes de entrar no catálogo.

## Resolução e bloqueio

Carregar catálogo local → parsear propriedades como dados UTF-8 → validar campos sem I/O externo → identificar qualquer DEFINIR do recurso → manter inativo; só depois conferir completude/tipos/compatibilidade. Sem marcador mas com faltante/vazio/inválido, também inativo. Disponível não é executado: o chamador precisa de fase/ação e autorização aplicáveis.

Autenticação opcional: modo selecionado deve declarar campos necessários e dispensáveis. NAO_APLICAVEL é representação proposta de decisão explícita para campo dispensável, nunca credencial padrão. Não passar marcadores ao serviço. Não assumir suporte a usuário/senha/token em determinada versão de Sonar ou outro serviço; declarar e testar no adaptador correspondente.

## Escrita protegida

Resolver raiz e destinos canonicamente; recusar arquivo no lugar de apps, travessia e links fora da raiz. Preparar conjunto de arquivos e checar conflitos antes da escrita. Para consumidor existente, gerar plano de diferenças/candidato; não resetar arquivo real. Fazer somente adição idempotente da regra de ignore, preservando linhas do usuário. Destinos já autorados exigem operação explícita de atualização com política própria.

## Testes futuros

Fixtures com hooks de rede/processo que falham se chamados em init/recursos DEFINIR; casos de config parcial, autenticação opcional, formato inválido, recursos independentes, reinit sem sobrescrita, apps preexistente, caminho/link malicioso e SPEC ausente. Evidência de cobertura e dois consumidores isolados; não utilizar credenciais reais ou serviços de produção. Testes de disponibilidade de infraestrutura não substituem teste negativo de não utilização.
