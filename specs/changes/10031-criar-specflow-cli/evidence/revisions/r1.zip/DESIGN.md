# Design — SpecFlow CLI r1

Candidato, sem implementação. Dependências: núcleo 10029 r5 e consumidor 10030 r3 aprovados e entregues conforme seus contratos.

## Organização

Usar o pacote specflow já previsto em framework/src/specflow. Adicionar cli como adaptador fino de argparse, sem duplicar contracts/workflow/memory/validation. Rotinas consumer/configuration cuidam de init e recursos; integrations cuida somente de materialização de arquivos; assets contém allowlist autoral. Não importar módulo do consumidor para descobrir configuração.

framework/pyproject.toml define name=specflow-cli, version=0.1.0, requires-python >=3.11, dependencies vazias, build-backend hatchling.build e project.scripts specflow=specflow.cli:main. __main__ delega ao mesmo main. Recursos carregados via importlib.resources, sem depender do cwd do checkout. Hatchling e cobertura são ferramentas de desenvolvimento, não runtime; fixar suas resoluções no ambiente de build/teste antes da implementação.

Wheel universal Python e sdist construídos em ambiente isolado, com inventário explícito. Wheel reconstruído do sdist precisa conter o mesmo conjunto de recursos e passar o mesmo smoke; não prometer bytes de ZIP idênticos sem controlar timestamps. Build não baixa recursos do consumidor ou da documentação histórica.

## Consumidor e escrita

Metadados em .specflow/project.json e .specflow/managed-files.json; Changes em specs/changes, conhecimento em specs/knowledge; políticas fixadas sob .specflow/policies. Manifesto registra versão e SHA-256 de baseline por arquivo gerenciado, sem credenciais. Configuração operacional é somente configuracao.properties. Preservar AGENTS.md/.github/copilot-instructions.md existentes; instalar instrução complementar com nome próprio, sem substituir esses arquivos. Template inicial autoral pode criar AGENTS.md somente quando ausente.

Inicialização prepara todos os arquivos em memória, resolve caminhos e valida conflitos antes de escrever. Arquivo gerenciado idêntico é no-op; bytes divergentes geram bloqueio, sem reescrita. Configuração já existente é autoral e preservada, inclusive parcial; chaves novas exigem candidato futuro, não reset. .gitignore recebe apenas linha de proteção faltante, preservando o conteúdo e newline existente. Se uma regra posterior negar a proteção, reportar conflito antes da escrita; não alegar proteção efetiva.

Usar criação exclusiva e validar novamente destinos antes de cada escrita. Falha durante escrita remove somente arquivos novos criados pela própria operação, sem apagar conteúdo preexistente; modificação concorrente interrompe rollback daquele arquivo e gera diagnóstico explícito. Não prometer transação global do filesystem. Recusar links/junctions nos destinos gerenciados da escrita e raiz/destinos que resolvam para fora da área autorizada. Nenhuma chamada a Git.

## Rascunhos e handoff

nova-change usa maior prefixo numérico existente +1, com largura mínima de cinco dígitos, slug ASCII do objetivo e criação exclusiva; no consumidor vazio começa 00001. Caracteres originais ficam no texto do objetivo, nunca em comando de shell. Reservar ID numérico em .specflow/reservations com criação exclusiva para evitar colisão concorrente. IDs reservados não são reciclados após falha; informar reserva/limite sem sobrescrever. Não criar change.json válido ou alegar EM_REVISAO_SPEC enquanto os documentos forem somente placeholders; registro draft.json indica rascunho e não é entrada aprovada do núcleo.

Handoff usa o catálogo docs/comandos/comandos.json: integrações selecionadas geram .agents/skills/specflow-*/SKILL.md e .github/prompts/specflow-*.prompt.md. Suporte autoral de auditoria fica em .agents/skills/security-audit e docs/security-audit, com protocolo/validador novos ou de direitos confirmados; não copiar skill legada sem confirmação de direitos. Todas as referências dos recursos embarcados precisam fechar dentro do consumidor.

JSON de operações administrativas/handoff: schemaVersion=1, operation, projectId/changeId quando disponíveis, outcome, phaseExecuted=false, editorInstructions, findings, pending, limitations e exitCode. Resultado de core conserva o envelope definido na 10029. Sem timestamp de execução e com ordenação estável. Códigos de argparse também precisam de representação JSON quando --json for solicitado; falha ao parsear não imprime objetivo/configuração sensível.

Pré-condições vêm da política do núcleo, não de cópias de enums na CLI. teste-humano sem aprovação apresenta instrução até revisão/decisão e código 1 com implementação bloqueada; com aprovação/plano válidos apresenta continuidade autorizada, sem declarar entrega executada. aprovar reúne as evidências e solicita registro humano pelo editor; CLI não possui comando de gravação de aprovação. encerrar reúne candidato e autorizações, sem movimentar ou versionar.

## Segurança e testes

doctor inspeciona versão do próprio pacote e existência de arquivos/declarações; não executa --version de recursos, probes de rede ou comandos de configuração. A guarda de recursos da 10030 é obrigatória em todos os adaptadores. Ausência de opcional não torna o núcleo indisponível; ausência de recurso necessário mantém o gate pendente.

validar confere revisão da implementação e invoca a função confiável do verificador empacotado com raiz e Change explícitas, sem shell/subprocesso nem carregamento de script do consumidor. Respeitar schema v1 de security-audit.json e saída security-gate.json; seu conteúdo não autentica reviewer. Gate 0 não promove VALIDADA/APROVADA. Não executar campos command das evidências.

Testes unittest em consumidores temporários, coverage.py somente no ambiente isolado de testes e relatório por arquivo/agregado. Hooks bloqueiam rede/processos nas operações que não os permitem; cenários de conflito, links, concorrência e interrupção de escrita exercitam comportamento real. Homologação de editor é etapa separada com versão/evidência humana; presença de arquivo não equivale a descoberta pelo cliente.
